import { Router } from 'express';
import { financingController } from './financing.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validation';
import { z } from 'zod';

const router = Router();

const financingSchema = z.object({
  propertyValue: z.number().positive(),
  downPayment: z.number().min(0),
  interestRate: z.number().positive(),
  loanTerm: z.number().int().positive(),
});

router.post('/', authenticate, validate({ body: financingSchema }), financingController.create);
router.get('/', authenticate, financingController.list);
router.get('/:id', authenticate, financingController.get);

export default router;
