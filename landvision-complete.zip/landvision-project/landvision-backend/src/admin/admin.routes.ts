import { Router } from 'express';
import { adminController } from './admin.controller';
import { authenticate, authorize } from '../middleware/auth';
import { validate } from '../middleware/validation';
import { z } from 'zod';

const router = Router();

// All admin routes require authentication and ADMIN role
router.use(authenticate, authorize('ADMIN'));

router.get('/users', adminController.getUsers);
router.patch('/users/:userId', validate({ body: z.object({ isActive: z.boolean().optional(), role: z.enum(['USER', 'ADMIN']).optional() }) }), adminController.updateUser);
router.get('/audit-logs', adminController.getAuditLogs);
router.get('/stats', adminController.getStats);

export default router;
