import { prisma } from '../config/database';
import { NotFoundError } from '../utils/errors';

export const adminService = {
  async getUsers(page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;
    const [users, total] = await Promise.all([
      prisma.user.findMany({
        skip,
        take: limit,
        include: { subscription: true },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.user.count(),
    ]);

    return { users: users.map(u => { const { passwordHash, ...user } = u; return user; }), total, page, limit };
  },

  async updateUser(userId: string, data: any) {
    const user = await prisma.user.update({ where: { id: userId }, data });
    const { passwordHash, ...sanitized } = user;
    return sanitized;
  },

  async getAuditLogs(page: number = 1, limit: number = 50) {
    const skip = (page - 1) * limit;
    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        skip,
        take: limit,
        include: { user: { select: { email: true, name: true } } },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.auditLog.count(),
    ]);

    return { logs, total, page, limit };
  },

  async getStats() {
    const [totalUsers, activeUsers, freeUsers, proUsers, totalValuations, totalDecisions] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { isActive: true } }),
      prisma.subscription.count({ where: { plan: 'FREE' } }),
      prisma.subscription.count({ where: { plan: 'PRO' } }),
      prisma.valuation.count(),
      prisma.decision.count(),
    ]);

    return { totalUsers, activeUsers, freeUsers, proUsers, totalValuations, totalDecisions };
  },
};
