import { Router } from 'express';
import { valuationsController } from './valuations.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validation';
import { z } from 'zod';

const router = Router();

const valuationSchema = z.object({
  cityId: z.string().uuid(),
  neighborhoodId: z.string().uuid().optional(),
  propertyType: z.enum(['APARTMENT', 'HOUSE', 'CONDO', 'LAND', 'COMMERCIAL']),
  area: z.number().positive(),
  bedrooms: z.number().int().min(0),
  bathrooms: z.number().int().min(0),
  parkingSpaces: z.number().int().min(0).optional(),
  age: z.number().int().min(0).optional(),
});

router.post('/', authenticate, validate({ body: valuationSchema }), valuationsController.create);
router.get('/', authenticate, valuationsController.list);
router.get('/:id', authenticate, valuationsController.get);

export default router;
