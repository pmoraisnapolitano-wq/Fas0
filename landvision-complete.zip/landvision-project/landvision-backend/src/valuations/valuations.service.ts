import { prisma } from '../config/database';
import { generateValuation, ValuationRequest } from '../ai/ai.service';
import { PaymentRequiredError, NotFoundError } from '../utils/errors';
import { PLAN_LIMITS } from '../config/stripe';

export const valuationsService = {
  async createValuation(userId: string, data: any) {
    // Check subscription and usage
    const subscription = await prisma.subscription.findUnique({ where: { userId } });
    if (!subscription) throw new NotFoundError('Subscription not found');

    const limit = PLAN_LIMITS[subscription.plan].valuations;
    if (limit !== -1 && subscription.valuationsUsed >= limit) {
      throw new PaymentRequiredError('Valuation limit exceeded. Please upgrade your plan.');
    }

    // Get city and neighborhood details
    const city = await prisma.city.findUnique({ where: { id: data.cityId }, include: { state: { include: { country: true } } } });
    if (!city) throw new NotFoundError('City not found');

    let neighborhood = null;
    if (data.neighborhoodId) {
      neighborhood = await prisma.neighborhood.findUnique({ where: { id: data.neighborhoodId } });
    }

    // Prepare AI request
    const aiRequest: ValuationRequest = {
      propertyType: data.propertyType,
      area: data.area,
      bedrooms: data.bedrooms,
      bathrooms: data.bathrooms,
      parkingSpaces: data.parkingSpaces || 0,
      age: data.age,
      cityName: city.name,
      neighborhoodName: neighborhood?.name,
      countryCode: city.state.country.code,
    };

    // Generate valuation with AI
    const aiResult = await generateValuation(aiRequest);

    // Create valuation record
    const valuation = await prisma.valuation.create({
      data: {
        userId,
        cityId: data.cityId,
        neighborhoodId: data.neighborhoodId,
        propertyType: data.propertyType,
        area: data.area,
        bedrooms: data.bedrooms,
        bathrooms: data.bathrooms,
        parkingSpaces: data.parkingSpaces || 0,
        age: data.age,
        estimatedValue: aiResult.estimatedValue,
        minValue: aiResult.minValue,
        maxValue: aiResult.maxValue,
        confidenceScore: aiResult.confidenceScore,
        aiAnalysis: aiResult.aiAnalysis,
        marketTrends: aiResult.marketTrends,
      },
    });

    // Update usage
    await prisma.subscription.update({ where: { userId }, data: { valuationsUsed: { increment: 1 } } });

    return valuation;
  },

  async getUserValuations(userId: string) {
    return await prisma.valuation.findMany({
      where: { userId },
      include: { city: true, neighborhood: true },
      orderBy: { createdAt: 'desc' },
    });
  },

  async getValuation(id: string, userId: string) {
    const valuation = await prisma.valuation.findFirst({
      where: { id, userId },
      include: { city: true, neighborhood: true },
    });
    if (!valuation) throw new NotFoundError('Valuation not found');
    return valuation;
  },
};
