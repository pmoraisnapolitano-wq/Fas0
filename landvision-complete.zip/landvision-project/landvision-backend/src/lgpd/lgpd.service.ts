import { prisma } from '../config/database';
import { NotFoundError } from '../utils/errors';
import { logger } from '../utils/logger';

export const lgpdService = {
  async exportUserData(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        subscription: true,
        valuations: true,
        decisions: true,
        financings: true,
        sessions: true,
        auditLogs: true,
      },
    });

    if (!user) throw new NotFoundError('User not found');

    // Log the data export
    await prisma.auditLog.create({
      data: {
        userId,
        action: 'DATA_EXPORT',
        resource: 'user',
        resourceId: userId,
        details: 'User data exported',
      },
    });

    const { passwordHash, ...userData } = user;
    return userData;
  },

  async requestDataDeletion(userId: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundError('User not found');

    // Log the deletion request
    await prisma.auditLog.create({
      data: {
        userId,
        action: 'DATA_DELETE_REQUEST',
        resource: 'user',
        resourceId: userId,
        details: 'User requested account deletion',
      },
    });

    // In production, this would trigger a workflow for manual review
    // For now, we'll deactivate the user and schedule deletion
    await prisma.user.update({
      where: { id: userId },
      data: { isActive: false },
    });

    logger.info(`User ${userId} requested account deletion`);

    return {
      message: 'Account deletion requested. Your data will be removed within 30 days.',
      scheduledDeletion: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    };
  },
};
