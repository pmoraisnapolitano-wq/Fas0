import { Request, Response } from 'express';
import { lgpdService } from './lgpd.service';
import { sendSuccess } from '../utils/response';
import { asyncHandler } from '../middleware/errorHandler';

export const lgpdController = {
  exportData: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const data = await lgpdService.exportUserData(userId);
    sendSuccess(res, data, 'Data exported successfully');
  }),

  requestDeletion: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const result = await lgpdService.requestDataDeletion(userId);
    sendSuccess(res, result);
  }),
};
