import { anthropic, AI_CONFIG, isAIAvailable } from '../config/ai';
import { logger } from '../utils/logger';
import { ServiceUnavailableError } from '../utils/errors';

/**
 * AI Service for property valuations and decision analysis
 * Uses Anthropic Claude with fallback to rule-based logic
 */

export interface ValuationRequest {
  propertyType: string;
  area: number;
  bedrooms: number;
  bathrooms: number;
  parkingSpaces: number;
  age?: number;
  cityName: string;
  neighborhoodName?: string;
  countryCode: string;
}

export interface ValuationResult {
  estimatedValue: number;
  minValue: number;
  maxValue: number;
  confidenceScore: number;
  aiAnalysis: string;
  marketTrends: string;
}

export interface DecisionRequest {
  propertyValue: number;
  rentalValue?: number;
  downPayment?: number;
  interestRate?: number;
  loanTerm?: number;
  monthlyIncome?: number;
}

export interface DecisionResult {
  recommendation: 'BUY' | 'RENT' | 'INVEST';
  score: number;
  buyAnalysis: string;
  rentAnalysis: string;
  investAnalysis: string;
  reasoning: string;
}

/**
 * Generate property valuation using AI
 */
export async function generateValuation(
  data: ValuationRequest
): Promise<ValuationResult> {
  if (isAIAvailable()) {
    try {
      return await generateValuationWithAI(data);
    } catch (error) {
      logger.error('AI valuation failed, using fallback:', error);
      return generateValuationFallback(data);
    }
  } else {
    return generateValuationFallback(data);
  }
}

/**
 * Generate decision analysis using AI
 */
export async function generateDecisionAnalysis(
  data: DecisionRequest
): Promise<DecisionResult> {
  if (isAIAvailable()) {
    try {
      return await generateDecisionWithAI(data);
    } catch (error) {
      logger.error('AI decision analysis failed, using fallback:', error);
      return generateDecisionFallback(data);
    }
  } else {
    return generateDecisionFallback(data);
  }
}

/**
 * AI-powered valuation
 */
async function generateValuationWithAI(
  data: ValuationRequest
): Promise<ValuationResult> {
  const prompt = `You are a real estate expert. Analyze this property and provide a valuation:

Property Details:
- Type: ${data.propertyType}
- Area: ${data.area} m²
- Bedrooms: ${data.bedrooms}
- Bathrooms: ${data.bathrooms}
- Parking Spaces: ${data.parkingSpaces}
- Age: ${data.age || 'New'} years
- Location: ${data.neighborhoodName || ''}, ${data.cityName}, ${data.countryCode}

Please provide:
1. Estimated market value
2. Value range (min-max)
3. Confidence score (0-1)
4. Detailed analysis
5. Current market trends

Format your response as JSON with these exact keys: estimatedValue, minValue, maxValue, confidenceScore, analysis, trends`;

  const response = await anthropic.messages.create({
    model: AI_CONFIG.model,
    max_tokens: AI_CONFIG.maxTokens,
    temperature: AI_CONFIG.temperature,
    messages: [
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  // Parse AI response
  const content = response.content[0];
  const text = content.type === 'text' ? content.text : '';
  
  try {
    const result = JSON.parse(text);
    return {
      estimatedValue: result.estimatedValue,
      minValue: result.minValue,
      maxValue: result.maxValue,
      confidenceScore: result.confidenceScore,
      aiAnalysis: result.analysis,
      marketTrends: result.trends,
    };
  } catch (error) {
    logger.error('Failed to parse AI response, using fallback');
    return generateValuationFallback(data);
  }
}

/**
 * Rule-based valuation fallback
 */
function generateValuationFallback(data: ValuationRequest): ValuationResult {
  // Simple rule-based calculation
  let basePrice = 2000; // base price per m² in USD

  // Adjust by property type
  const typeMultipliers: Record<string, number> = {
    APARTMENT: 1.0,
    HOUSE: 1.2,
    CONDO: 1.1,
    LAND: 0.5,
    COMMERCIAL: 1.5,
  };
  basePrice *= typeMultipliers[data.propertyType] || 1.0;

  // Calculate base value
  const baseValue = data.area * basePrice;

  // Adjustments
  let adjustedValue = baseValue;
  adjustedValue += data.bedrooms * 10000;
  adjustedValue += data.bathrooms * 5000;
  adjustedValue += data.parkingSpaces * 8000;

  // Age depreciation
  if (data.age && data.age > 0) {
    const depreciation = Math.min(data.age * 0.02, 0.4); // max 40% depreciation
    adjustedValue *= 1 - depreciation;
  }

  // Calculate range (±15%)
  const minValue = adjustedValue * 0.85;
  const maxValue = adjustedValue * 1.15;

  return {
    estimatedValue: Math.round(adjustedValue),
    minValue: Math.round(minValue),
    maxValue: Math.round(maxValue),
    confidenceScore: 0.65,
    aiAnalysis: `Based on the property specifications (${data.area}m², ${data.bedrooms} bed, ${data.bathrooms} bath), the estimated value is calculated using market averages for ${data.propertyType.toLowerCase()} properties in ${data.cityName}.`,
    marketTrends: 'Market data suggests stable prices with moderate growth potential. Local demand indicators show balanced supply and demand.',
  };
}

/**
 * AI-powered decision analysis
 */
async function generateDecisionWithAI(
  data: DecisionRequest
): Promise<DecisionResult> {
  const prompt = `You are a financial advisor. Analyze this real estate scenario and recommend whether to BUY, RENT, or INVEST:

Scenario:
- Property Value: $${data.propertyValue}
- Monthly Rent: $${data.rentalValue || 'unknown'}
- Down Payment: $${data.downPayment || 'unknown'}
- Interest Rate: ${data.interestRate || 'unknown'}%
- Loan Term: ${data.loanTerm || 'unknown'} months
- Monthly Income: $${data.monthlyIncome || 'unknown'}

Please provide:
1. Recommendation (BUY, RENT, or INVEST)
2. Confidence score (0-100)
3. Detailed analysis for buying
4. Detailed analysis for renting
5. Detailed analysis for investing
6. Overall reasoning

Format your response as JSON with these exact keys: recommendation, score, buyAnalysis, rentAnalysis, investAnalysis, reasoning`;

  const response = await anthropic.messages.create({
    model: AI_CONFIG.model,
    max_tokens: AI_CONFIG.maxTokens,
    temperature: AI_CONFIG.temperature,
    messages: [
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  const content = response.content[0];
  const text = content.type === 'text' ? content.text : '';

  try {
    const result = JSON.parse(text);
    return {
      recommendation: result.recommendation,
      score: result.score,
      buyAnalysis: result.buyAnalysis,
      rentAnalysis: result.rentAnalysis,
      investAnalysis: result.investAnalysis,
      reasoning: result.reasoning,
    };
  } catch (error) {
    logger.error('Failed to parse AI response, using fallback');
    return generateDecisionFallback(data);
  }
}

/**
 * Rule-based decision fallback
 */
function generateDecisionFallback(data: DecisionRequest): DecisionResult {
  const { propertyValue, rentalValue, downPayment, interestRate, monthlyIncome } = data;

  let buyScore = 50;
  let rentScore = 50;
  let investScore = 50;

  // Calculate price-to-rent ratio if available
  if (rentalValue) {
    const annualRent = rentalValue * 12;
    const priceToRentRatio = propertyValue / annualRent;

    if (priceToRentRatio < 15) {
      buyScore += 20;
    } else if (priceToRentRatio > 20) {
      rentScore += 20;
    }
  }

  // Consider down payment capability
  if (downPayment && monthlyIncome) {
    const downPaymentRatio = downPayment / propertyValue;
    if (downPaymentRatio >= 0.2) {
      buyScore += 15;
    } else {
      rentScore += 15;
    }
  }

  // Consider interest rate
  if (interestRate) {
    if (interestRate < 5) {
      buyScore += 10;
    } else if (interestRate > 8) {
      rentScore += 10;
      investScore += 10;
    }
  }

  // Determine recommendation
  let recommendation: 'BUY' | 'RENT' | 'INVEST';
  let topScore: number;

  if (buyScore >= rentScore && buyScore >= investScore) {
    recommendation = 'BUY';
    topScore = buyScore;
  } else if (rentScore >= buyScore && rentScore >= investScore) {
    recommendation = 'RENT';
    topScore = rentScore;
  } else {
    recommendation = 'INVEST';
    topScore = investScore;
  }

  return {
    recommendation,
    score: topScore,
    buyAnalysis: `Buying may be suitable with current interest rates ${interestRate ? `at ${interestRate}%` : ''}. Consider the long-term appreciation potential and stability of homeownership.`,
    rentAnalysis: `Renting provides flexibility and requires less upfront capital. Monthly rent of $${rentalValue || 'TBD'} may be competitive compared to mortgage payments.`,
    investAnalysis: `Alternative investments might offer better returns depending on market conditions. Consider diversification and liquidity needs.`,
    reasoning: `Based on the financial parameters, ${recommendation.toLowerCase()}ing appears to be the most suitable option with a confidence score of ${topScore}/100. This takes into account the property value, potential rental income, and your financial capacity.`,
  };
}
