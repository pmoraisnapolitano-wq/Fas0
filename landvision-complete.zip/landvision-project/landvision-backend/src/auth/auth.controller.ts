import { Request, Response } from 'express';
import { authService } from './auth.service';
import { sendSuccess } from '../utils/response';
import { asyncHandler } from '../middleware/errorHandler';
import { prisma } from '../config/database';

export const authController = {
  register: asyncHandler(async (req: Request, res: Response) => {
    const { email, password, name } = req.body;
    const result = await authService.register(email, password, name);
    sendSuccess(res, result, 'User registered successfully', 201);
  }),

  login: asyncHandler(async (req: Request, res: Response) => {
    const { email, password } = req.body;
    const userAgent = req.get('user-agent');
    const ipAddress = req.ip;
    const result = await authService.login(email, password, userAgent, ipAddress);
    sendSuccess(res, result, 'Login successful');
  }),

  refreshToken: asyncHandler(async (req: Request, res: Response) => {
    const { refreshToken } = req.body;
    const result = await authService.refreshToken(refreshToken);
    sendSuccess(res, result, 'Token refreshed');
  }),

  logout: asyncHandler(async (req: Request, res: Response) => {
    const { refreshToken } = req.body;
    const accessToken = req.headers.authorization?.substring(7) || '';
    await authService.logout(refreshToken, accessToken);
    sendSuccess(res, null, 'Logout successful');
  }),

  getProfile: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { subscription: true },
    });
    sendSuccess(res, authService.sanitizeUser(user), 'Profile retrieved');
  }),
};
