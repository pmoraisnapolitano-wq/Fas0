import { Router } from 'express';
import { decisionsController } from './decisions.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validation';
import { z } from 'zod';

const router = Router();

const decisionSchema = z.object({
  propertyValue: z.number().positive(),
  rentalValue: z.number().positive().optional(),
  downPayment: z.number().min(0).optional(),
  interestRate: z.number().positive().optional(),
  loanTerm: z.number().int().positive().optional(),
  monthlyIncome: z.number().positive().optional(),
});

router.post('/', authenticate, validate({ body: decisionSchema }), decisionsController.create);
router.get('/', authenticate, decisionsController.list);
router.get('/:id', authenticate, decisionsController.get);

export default router;
