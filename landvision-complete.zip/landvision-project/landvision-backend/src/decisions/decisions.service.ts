import { prisma } from '../config/database';
import { generateDecisionAnalysis, DecisionRequest } from '../ai/ai.service';
import { PaymentRequiredError, NotFoundError } from '../utils/errors';
import { PLAN_LIMITS } from '../config/stripe';

export const decisionsService = {
  async createDecision(userId: string, data: any) {
    const subscription = await prisma.subscription.findUnique({ where: { userId } });
    if (!subscription) throw new NotFoundError('Subscription not found');

    const limit = PLAN_LIMITS[subscription.plan].decisions;
    if (limit !== -1 && subscription.decisionsUsed >= limit) {
      throw new PaymentRequiredError('Decision analysis limit exceeded. Please upgrade your plan.');
    }

    const aiRequest: DecisionRequest = {
      propertyValue: data.propertyValue,
      rentalValue: data.rentalValue,
      downPayment: data.downPayment,
      interestRate: data.interestRate,
      loanTerm: data.loanTerm,
      monthlyIncome: data.monthlyIncome,
    };

    const aiResult = await generateDecisionAnalysis(aiRequest);

    const decision = await prisma.decision.create({
      data: {
        userId,
        propertyValue: data.propertyValue,
        rentalValue: data.rentalValue,
        downPayment: data.downPayment,
        interestRate: data.interestRate,
        loanTerm: data.loanTerm,
        monthlyIncome: data.monthlyIncome,
        recommendation: aiResult.recommendation,
        score: aiResult.score,
        buyAnalysis: aiResult.buyAnalysis,
        rentAnalysis: aiResult.rentAnalysis,
        investAnalysis: aiResult.investAnalysis,
        reasoning: aiResult.reasoning,
      },
    });

    await prisma.subscription.update({ where: { userId }, data: { decisionsUsed: { increment: 1 } } });

    return decision;
  },

  async getUserDecisions(userId: string) {
    return await prisma.decision.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  },

  async getDecision(id: string, userId: string) {
    const decision = await prisma.decision.findFirst({ where: { id, userId } });
    if (!decision) throw new NotFoundError('Decision not found');
    return decision;
  },
};
