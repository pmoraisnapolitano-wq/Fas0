import { Request, Response } from 'express';
import { paymentsService } from './payments.service';
import { sendSuccess } from '../utils/response';
import { asyncHandler } from '../middleware/errorHandler';

export const paymentsController = {
  createCheckout: asyncHandler(async (req: Request, res: Response) => {
    const { plan } = req.body;
    const userId = req.user!.userId;
    const result = await paymentsService.createCheckoutSession(userId, plan);
    sendSuccess(res, result, 'Checkout session created');
  }),
};
