import { Router } from 'express';
import { paymentsController } from './payments.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validation';
import { z } from 'zod';

const router = Router();

router.post('/checkout', authenticate, validate({ body: z.object({ plan: z.enum(['FREE', 'PRO']) }) }), paymentsController.createCheckout);

export default router;
