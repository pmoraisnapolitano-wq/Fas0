import { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/errors';
import { sendError } from '../utils/response';
import { logger } from '../utils/logger';
import { Prisma } from '@prisma/client';

/**
 * Global Error Handler Middleware
 * Catches all errors and sends appropriate responses
 */
export const errorHandler = (
  error: Error,
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  // Log error
  logger.error('Error occurred:', {
    message: error.message,
    stack: error.stack,
    path: req.path,
    method: req.method,
    ip: req.ip,
  });

  // Handle known operational errors
  if (error instanceof AppError) {
    const statusCode = error.statusCode || 500;
    const message = error.message || 'Internal server error';
    
    // Include validation errors if present
    const errors = (error as any).errors;
    
    return sendError(res, message, statusCode, errors);
  }

  // Handle Prisma errors
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    return handlePrismaError(error, res);
  }

  // Handle validation errors from other libraries
  if (error.name === 'ValidationError') {
    return sendError(res, error.message, 400);
  }

  // Handle JWT errors
  if (error.name === 'JsonWebTokenError') {
    return sendError(res, 'Invalid token', 401);
  }

  if (error.name === 'TokenExpiredError') {
    return sendError(res, 'Token expired', 401);
  }

  // Handle unexpected errors
  const statusCode = 500;
  const message = process.env.NODE_ENV === 'production'
    ? 'Internal server error'
    : error.message;

  sendError(res, message, statusCode);
};

/**
 * Handle Prisma-specific errors
 */
const handlePrismaError = (
  error: Prisma.PrismaClientKnownRequestError,
  res: Response
): void => {
  switch (error.code) {
    case 'P2002':
      // Unique constraint violation
      const field = (error.meta?.target as string[]) || ['field'];
      sendError(res, `${field.join(', ')} already exists`, 409);
      break;

    case 'P2025':
      // Record not found
      sendError(res, 'Resource not found', 404);
      break;

    case 'P2003':
      // Foreign key constraint violation
      sendError(res, 'Invalid reference to related resource', 400);
      break;

    case 'P2014':
      // Relation violation
      sendError(res, 'Operation violates data relations', 400);
      break;

    default:
      logger.error('Unhandled Prisma error:', error);
      sendError(res, 'Database error occurred', 500);
  }
};

/**
 * Handle 404 Not Found
 */
export const notFoundHandler = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  sendError(res, `Route ${req.method} ${req.path} not found`, 404);
};

/**
 * Async error wrapper
 * Wraps async route handlers to catch errors
 */
export const asyncHandler = (
  fn: (req: Request, res: Response, next: NextFunction) => Promise<any>
) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
