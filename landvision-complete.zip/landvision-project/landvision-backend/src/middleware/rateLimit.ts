import { Request, Response, NextFunction } from 'express';
import { incrementRateLimit } from '../config/redis';
import { RateLimitError } from '../utils/errors';
import { logger } from '../utils/logger';

/**
 * Rate Limiting Configuration
 */
const RATE_LIMIT_CONFIG = {
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'),
};

/**
 * Rate Limiting Middleware
 * Uses Redis to track request counts per IP
 */
export const rateLimitMiddleware = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    // Get client IP
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const key = `ratelimit:${ip}`;

    // Increment counter
    const requests = await incrementRateLimit(key, RATE_LIMIT_CONFIG.windowMs);

    // Set rate limit headers
    res.setHeader('X-RateLimit-Limit', RATE_LIMIT_CONFIG.max);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, RATE_LIMIT_CONFIG.max - requests));
    res.setHeader('X-RateLimit-Reset', Date.now() + RATE_LIMIT_CONFIG.windowMs);

    // Check if limit exceeded
    if (requests > RATE_LIMIT_CONFIG.max) {
      logger.warn(`Rate limit exceeded for IP: ${ip}`);
      throw new RateLimitError('Too many requests, please try again later');
    }

    next();
  } catch (error) {
    if (error instanceof RateLimitError) {
      next(error);
    } else {
      logger.error('Rate limit middleware error:', error);
      // Continue on Redis errors
      next();
    }
  }
};

/**
 * Custom rate limiter with configurable options
 */
export const createRateLimiter = (options: {
  windowMs: number;
  max: number;
  keyGenerator?: (req: Request) => string;
}) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // Generate key
      const key = options.keyGenerator
        ? options.keyGenerator(req)
        : `ratelimit:${req.ip || 'unknown'}`;

      // Increment counter
      const requests = await incrementRateLimit(key, options.windowMs);

      // Set headers
      res.setHeader('X-RateLimit-Limit', options.max);
      res.setHeader('X-RateLimit-Remaining', Math.max(0, options.max - requests));
      res.setHeader('X-RateLimit-Reset', Date.now() + options.windowMs);

      // Check limit
      if (requests > options.max) {
        logger.warn(`Rate limit exceeded for key: ${key}`);
        throw new RateLimitError('Too many requests, please try again later');
      }

      next();
    } catch (error) {
      if (error instanceof RateLimitError) {
        next(error);
      } else {
        logger.error('Rate limit error:', error);
        next();
      }
    }
  };
};

/**
 * Rate limiter for authenticated users
 */
export const authRateLimiter = createRateLimiter({
  windowMs: 60000, // 1 minute
  max: 60,
  keyGenerator: (req: Request) => `ratelimit:user:${req.user?.userId || req.ip}`,
});
