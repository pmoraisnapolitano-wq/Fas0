import Anthropic from '@anthropic-ai/sdk';
import { logger } from '../utils/logger';

if (!process.env.ANTHROPIC_API_KEY) {
  logger.warn('⚠️  ANTHROPIC_API_KEY is not defined. AI features will use fallback.');
}

/**
 * Anthropic Claude Configuration
 */
export const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || '',
});

export const AI_CONFIG = {
  model: process.env.AI_MODEL || 'claude-3-sonnet-20240229',
  maxTokens: parseInt(process.env.AI_MAX_TOKENS || '4096'),
  temperature: 0.7,
};

/**
 * AI Model availability check
 */
export const isAIAvailable = (): boolean => {
  return !!process.env.ANTHROPIC_API_KEY;
};

if (isAIAvailable()) {
  logger.info('✅ Anthropic AI initialized successfully');
} else {
  logger.warn('⚠️  Anthropic AI not configured. Using fallback mode.');
}
