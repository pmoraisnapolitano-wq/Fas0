import Stripe from 'stripe';
import { logger } from '../utils/logger';

if (!process.env.STRIPE_SECRET_KEY) {
  logger.error('❌ STRIPE_SECRET_KEY is not defined in environment variables');
  throw new Error('STRIPE_SECRET_KEY is required');
}

/**
 * Stripe Client Configuration
 */
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
  typescript: true,
});

/**
 * Stripe Price IDs for subscription plans
 */
export const STRIPE_PLANS = {
  FREE: process.env.STRIPE_FREE_PRICE_ID || '',
  PRO: process.env.STRIPE_PRO_PRICE_ID || '',
};

/**
 * Stripe Webhook Secret
 */
export const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || '';

/**
 * Plan limits
 */
export const PLAN_LIMITS = {
  FREE: {
    valuations: 5,
    decisions: 3,
    financings: 3,
  },
  PRO: {
    valuations: -1, // unlimited
    decisions: -1,
    financings: -1,
  },
};

logger.info('✅ Stripe initialized successfully');
