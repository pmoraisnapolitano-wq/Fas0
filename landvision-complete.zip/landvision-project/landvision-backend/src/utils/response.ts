import { Response } from 'express';

/**
 * Standard API Response Interface
 */
export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
  errors?: any[];
  metadata?: {
    page?: number;
    limit?: number;
    total?: number;
    timestamp?: string;
  };
}

/**
 * Send success response
 */
export const sendSuccess = <T>(
  res: Response,
  data?: T,
  message?: string,
  statusCode: number = 200,
  metadata?: ApiResponse['metadata']
): void => {
  const response: ApiResponse<T> = {
    success: true,
    message,
    data,
    metadata: {
      ...metadata,
      timestamp: new Date().toISOString(),
    },
  };

  res.status(statusCode).json(response);
};

/**
 * Send error response
 */
export const sendError = (
  res: Response,
  error: string,
  statusCode: number = 500,
  errors?: any[]
): void => {
  const response: ApiResponse = {
    success: false,
    error,
    errors,
    metadata: {
      timestamp: new Date().toISOString(),
    },
  };

  res.status(statusCode).json(response);
};

/**
 * Send paginated response
 */
export const sendPaginated = <T>(
  res: Response,
  data: T[],
  page: number,
  limit: number,
  total: number,
  message?: string
): void => {
  const response: ApiResponse<T[]> = {
    success: true,
    message,
    data,
    metadata: {
      page,
      limit,
      total,
      timestamp: new Date().toISOString(),
    },
  };

  res.status(200).json(response);
};

/**
 * Send created response (201)
 */
export const sendCreated = <T>(
  res: Response,
  data: T,
  message: string = 'Resource created successfully'
): void => {
  sendSuccess(res, data, message, 201);
};

/**
 * Send no content response (204)
 */
export const sendNoContent = (res: Response): void => {
  res.status(204).send();
};
