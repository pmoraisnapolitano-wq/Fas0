import { prisma } from '../config/database';
import { NotFoundError } from '../utils/errors';

export const regionsService = {
  // Countries
  async getCountries() {
    return await prisma.country.findMany({ where: { active: true } });
  },
  
  async getCountry(id: string) {
    const country = await prisma.country.findUnique({ where: { id } });
    if (!country) throw new NotFoundError('Country not found');
    return country;
  },

  async createCountry(data: { name: string; code: string; currency: string }) {
    return await prisma.country.create({ data });
  },

  // States
  async getStates(countryId: string) {
    return await prisma.state.findMany({ where: { countryId, active: true } });
  },

  async createState(data: { countryId: string; name: string; code: string }) {
    return await prisma.state.create({ data });
  },

  // Cities
  async getCities(stateId: string) {
    return await prisma.city.findMany({ where: { stateId, active: true } });
  },

  async createCity(data: { stateId: string; name: string }) {
    return await prisma.city.create({ data });
  },

  // Neighborhoods
  async getNeighborhoods(cityId: string) {
    return await prisma.neighborhood.findMany({ where: { cityId, active: true } });
  },

  async createNeighborhood(data: { cityId: string; name: string; zone?: string }) {
    return await prisma.neighborhood.create({ data });
  },
};
