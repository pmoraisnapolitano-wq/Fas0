import Link from 'next/link';

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <nav className="container-custom py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary-600">LandVision</h1>
          <div className="space-x-4">
            <Link href="/login" className="btn btn-outline">Login</Link>
            <Link href="/register" className="btn btn-primary">Get Started</Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container-custom py-20">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            AI-Powered Real Estate Intelligence
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Make smarter property decisions with our advanced valuation and analysis platform
          </p>
          <div className="space-x-4">
            <Link href="/register" className="btn btn-primary text-lg px-8 py-3">
              Start Free Trial
            </Link>
            <Link href="/pricing" className="btn btn-outline text-lg px-8 py-3">
              View Pricing
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-gray-100 py-20">
        <div className="container-custom">
          <h3 className="text-3xl font-bold text-center mb-12">Key Features</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card text-center">
              <div className="text-4xl mb-4">🏠</div>
              <h4 className="text-xl font-semibold mb-2">Property Valuation</h4>
              <p className="text-gray-600">AI-powered property value estimation with market insights</p>
            </div>
            <div className="card text-center">
              <div className="text-4xl mb-4">🧠</div>
              <h4 className="text-xl font-semibold mb-2">Decision Analysis</h4>
              <p className="text-gray-600">Should you buy, rent, or invest? Get expert recommendations</p>
            </div>
            <div className="card text-center">
              <div className="text-4xl mb-4">📊</div>
              <h4 className="text-xl font-semibold mb-2">Financing Tools</h4>
              <p className="text-gray-600">Calculate loan payments and compare financing options</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container-custom text-center">
          <p>&copy; 2024 LandVision. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
