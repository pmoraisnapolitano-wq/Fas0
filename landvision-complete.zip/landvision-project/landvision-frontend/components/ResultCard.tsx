'use client';

import { ReactNode } from 'react';

interface ResultCardProps {
  title: string;
  children: ReactNode;
  className?: string;
}

export default function ResultCard({ title, children, className = '' }: ResultCardProps) {
  return (
    <div className={`card ${className}`}>
      <h3 className="text-xl font-semibold mb-4 text-gray-900">{title}</h3>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

export function ResultItem({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
      <span className="text-gray-600">{label}</span>
      <span className="font-semibold text-gray-900">{value}</span>
    </div>
  );
}
